# HiTS-Leftraru
This scripts run differents task in Leftraru cluser at NLHPC-CMM
