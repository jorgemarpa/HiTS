#!/bin/bash
#
#SBATCH -J test_job
#SBATCH --output=/home/jmartinez/HiTS/logs/diff_lc.o%A
#SBATCH --error=/home/jmartinez/HiTS/errors/diff_lc.%j.err
#SBATCH --ntasks 60
#SBATCH --mem-per-cpu=10
#

echo "Building lig-curves for list of coordinate"

MAX_CONCURRENT_STEPS=$SLURM_NTASKS
ip=$(ip -o -4 addr list eno1 | awk '{print $4}' | cut -d/ -f1)

seconds=0

cat file | xargs -n 1 -P $MAX_CONCURRENT_STEPS  srun --exclusive -n 1 -c 1 python buildLC.py -n galaxy -f Blind14A_01 -c N1 -r 2 -m ij -x 334 -y 2611

#seq -f "S%g" 1 $NUM_STEPS | xargs -n 1 -P $MAX_CONCURRENT_STEPS  srun --exclusive -n 1 -c 1 python influxdb_HiTS.py -t True -i $ip -F $1 -c

duration=$SECONDS
echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."

echo "Finished job"
exit 0
